# Ejercicios: el del lunes y los cinco de después

Todos se hacen en el chat que ya usas (ChatGPT, Claude, Gemini) y con una carpeta en tu ordenador. Sin terminal, sin instalar nada. Tiempo real, no optimista.

## El del lunes: la semilla (30 minutos)

1. Escribe seis líneas sobre tu negocio como se lo contarías a alguien en un bar: quién eres, qué vendes y a qué precio, a quién, qué te diferencia, qué no quieres parecer, por dónde vendes.
2. Abre el prompt `montar_el_cerebro` del kit, pega tu semilla al final y envíalo.
3. Salen cuatro documentos. Donde ponga `[PREGUNTAR AL DUEÑO]`, contesta. Guárdalos en una carpeta `00_CEREBRO` como cuatro archivos de texto.
4. Haz una pregunta real de tu negocio dos veces: una en un chat vacío, otra pegando antes los cuatro documentos. Compara.

Si la segunda respuesta te pregunta algo que la primera se inventó, ya has entendido la charla.

## Cuando tengas el primero

**2. La cruz de tareas (10 minutos).** Lista diez tareas de tu semana. Para cada una, dos preguntas: ¿cuánto cuesta que salga mal? ¿la IA tiene una nota con instrucciones para hacerla bien? Colócalas en la cruz del kit. Las de "solo tú" sin nota son las que más te cuestan; una nota cada semana y se mueven de columna.

**3. El patrón (15 minutos).** Pega treinta reseñas, comentarios o correos de clientes en el chat, con los cuatro documentos delante. Pide: "¿qué cinco patrones se repiten y qué pregunta hace la gente que nadie contesta en nuestra web?". La IA es muy buena detectando patrones y muy mala inventando clientes; dale los reales.

**4. La nota de un área (30 minutos).** Elige el área que más te duele (finanzas, clientes, campañas). Rellena la plantilla `plantilla_nota_de_area`: instrucciones, llamadas a tus archivos reales (qué Excel, qué hoja, qué columnas), síntesis de cinco líneas con fecha, decisiones. Vuelve a hacer la pregunta del lunes con esa nota delante.

**5. Tu primera skill (30 minutos).** Coge una tarea que repites cada semana (descripción de producto, respuesta a una reseña, post de Instagram). Escribe un archivo con cuatro bloques: cuándo se usa, pasos, formato de salida, y tres ejemplos tuyos buenos y dos malos con por qué son malos. Eso es una skill. Una skill de marketing genérica bajada de internet no tiene tus ejemplos; por eso no funciona.

**6. La auditoría (10 minutos).** Pega tu último anuncio o post y pregunta: "¿qué regla de 04_REGLAS incumple y qué dato de 02_QUE no coincide?". Si no incumple nada, sube el listón de las reglas.

## La regla de las tres semanas

Semana 1: la semilla y una pregunta. Semana 2: una nota de área y la cruz. Semana 3: una skill y la revisión mensual de 15 minutos. Si en tres semanas el cerebro no te ha ahorrado una tarde, escríbeme y lo miramos.
