---
name: anuncio-ia
description: Crea anuncios en vídeo con IA optimizados para vender (UGC o cinematográfico) desde una foto de producto y el cerebro del negocio, con cualquier Claude que tenga un conector de generación de vídeo (Higgsfield, Freepik/Seedance, Kling). Úsala cuando digan "/anuncio-ia", "hazme un anuncio", "anuncio para Instagram/TikTok de este producto", "spot con IA" o "versión cinematográfica de este vídeo".
---

# Anuncio con IA que vende (sept 2026)

Basada en los patrones de los anuncios con IA con cifras públicas (ver `PATRONES - anuncios con IA que funcionaron` en el kit). Regla de oro: el modelo pone el acabado; el cerebro pone lo que vende.

## Entradas

1. Foto del producto (obligatoria). Si hay varias, la que muestre el producto entero y de lado.
2. Foto de la persona que lo presenta (opcional; si es real, hace falta su consentimiento explícito antes de generar).
3. El cerebro del negocio si existe: `01_QUIEN` (voz), `02_QUE` (precio, plazos), `03_PARA_QUIEN` (a quién le hablas), `04_REGLAS` (líneas rojas). Si no existe, pide seis líneas sobre el negocio y trabaja con eso marcando `[PREGUNTAR AL DUEÑO]` en lo que falte.
4. Formato y destino: vertical 9:16 para Instagram/TikTok, horizontal 16:9 para YouTube o pantalla. Duración 10 a 15 s para UGC, 15 a 30 s para cinematográfico.

## Proceso

**Paso 1. Registro.** Elige uno y dilo antes de generar:
- UGC de móvil: calle o tienda real, luz de día, plano medio, habla como en la tienda. Es el que más vende para pymes y el que mejor perdona los errores del modelo.
- Cinematográfico: noche, contraluz, avance lento de cámara, texto o voz breve. Para marca, cierres y avatares. Pedir siempre luz de relleno en la cara; el contraluz puro la pierde en proyector y en móvil.
Nunca: emoción nostálgica con pretensión de realismo perfecto. Es donde la IA más se nota y donde los estudios miden rechazo.

**Paso 2. Guion de 3 partes, con fricción.** Máximo 35 palabras para 15 s.
- Gancho (3 s): dolor o secreto, producto ya en la mano. Nada de "descubre" ni "increíble".
- Cuerpo: una pega o una sorpresa real ("no me las quito", "pesa la mitad de lo que parece").
- Cierre con condición real de la ficha: precio exacto, plazo, cambio o devolución, dónde comprar. Todo sale de `02_QUE`; si no está, `[PREGUNTAR AL DUEÑO]`, nunca inventado.
Prohibido por `04_REGLAS` por defecto: "últimas unidades", "exclusivo", descuentos no confirmados, comparaciones con marcas.

**Paso 3. Prompt para el generador.** Estructura fija:
```
[Formato y duración] + [registro y localización concreta: ciudad, calle, luz] +
[persona de la referencia: cara, pelo, ropa, "exactamente"] +
[producto de la referencia: modelo y colores, "exactamente ese"] +
[planos: medio → detalle en mano → medio] +
[voz: idioma y acento, labios sincronizados, texto literal entre comillas] +
[prohibiciones: sin texto en pantalla, sin subtítulos, sin logos añadidos, sin música, sin frases prohibidas]
```
Referencias: producto como `product`, persona como `character` (dos fotogramas si hay vídeo), localización real como `image` si se quiere la calle de verdad (fotos libres de Wikimedia sirven; guarda la licencia).

**Paso 4. Generar.** Modelo por defecto: Seedance 2.5 (voz nativa en castellano, referencias de producto y personaje, 5 a 7 minutos). Alternativa: Kling 3.0 en Higgsfield. Una generación por variante; iterar el prompt, no el modelo. Presupuesta tirar la mitad.

**Paso 5. QC obligatorio antes de entregar.**
- Ver todos los frames a 1 fps: producto correcto (modelo, color, logo), manos, texto fantasma.
- Transcribir el audio y comparar palabra por palabra con el guion. Si el modelo cambia una cifra, se repite.
- Si hay voz clonada o avatar: remuxar siempre la pista de voz buena encima; el modelo no conserva el timbre del audio de referencia.
- Nivel de audio: normalizar a −14 LUFS y escucharlo en un móvil antes de dar por bueno.

**Paso 6. Etiqueta.** Dos segundos finales o sobreimpresión: "Contenido generado con IA". Obligatorio en la UE desde el 2 de agosto de 2026. Anotar en la ficha de la campaña: modelo usado, fecha, prompt exacto, referencias y consentimientos.

## Salida

- El vídeo final con etiqueta.
- El prompt exacto usado (para repetirlo con otra herramienta cuando esta caduque).
- Dos líneas: qué revisar antes de publicar y qué variante probar si no rinde (otro gancho, otro registro).

## Ejemplo real (charla Cluster TIC, sept 2026)

Mismo producto y misma persona, dos prompts. Sin cerebro: "una chica joven lo presenta y lo recomienda" → calle genérica, discurso de influencer. Con cerebro: calle de Uría en Oviedo, "las tenemos en la tienda y en la web, 130 euros, stock real, si no te quedan bien las cambias en 30 días y ya". La diferencia se ve sin explicarla.
