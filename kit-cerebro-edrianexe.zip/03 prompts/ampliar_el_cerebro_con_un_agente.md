---
tags: [prompt, metodo]
---
# Ampliar el cerebro con un agente asistente

Para anadir un area nueva (finanzas, RRHH, proveedores, lo que sea) sin romper lo que hay:

1. Dile al agente: "Lee 00_INDICE y los 4 documentos del nucleo. Quiero anadir el area X. Propon una carpeta nueva con sus notas, cada una enlazada al nucleo, y no toques nada de lo existente."
2. Revisa la propuesta. Acepta la estructura, no el contenido.
3. Dale los datos reales del area (una hoja, un export, una foto del cuaderno). El agente rellena las notas y marca [PREGUNTAR AL DUENO] donde no llegue.
4. Anade la carpeta a [[00_INDICE]] y una regla nueva a [[04_REGLAS]] si el area la necesita.
5. Prueba con una pregunta real (ver [[10_DEMOS/_demos|demos]]). Si la respuesta cita las notas correctas, el area esta viva.

Asi se montaron aqui 05_FINANZAS y 06_TENDENCIAS: primero la estructura, luego los datos, luego una pregunta.
