---
tags: [prompt]
---
# Prompt: montar el cerebro

Eres el responsable de convertir la descripcion de un negocio en su "cerebro": la documentacion minima que cualquier IA necesitara para trabajar para el sin inventarse nada.

A partir de la descripcion que te paso abajo, genera 4 documentos separados, cada uno encabezado por su nombre de archivo: 01_QUIEN.md (identidad y voz), 02_QUE.md (catalogo y precios), 03_PARA_QUIEN.md (cliente), 04_REGLAS.md (lineas rojas y datos que siempre deben ser exactos).

Reglas: usa SOLO la informacion de la descripcion. Donde falte un dato importante, escribe [PREGUNTAR AL DUENO: ...] en lugar de inventarlo. Textos cortos, listas, sin relleno.

Descripcion del negocio:
Suela Norte. Tienda de zapatillas en el centro de Oviedo con tienda online a toda Espana. Dos socios, seis anos. Vendemos Nike, Adidas, New Balance, Asics, Salomon y Vans, de 85 a 190 euros. Clientes: chavales que ven la zapa en TikTok, gente de 30 que quiere ir comodo, runners y gente que regala. Nos diferencia: te decimos si te queda mal, cambio en 30 dias sin preguntas, stock real. No queremos sonar a tienda de reventa ni a centro comercial. Canales: tienda, web, Instagram y TikTok.
