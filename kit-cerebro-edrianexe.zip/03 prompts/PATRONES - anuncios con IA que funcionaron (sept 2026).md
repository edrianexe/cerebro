# Patrones de los anuncios con IA que funcionaron (a 23 de septiembre de 2026)

Sacado de los casos con cifras públicas, no de opiniones. Lo que se repite en los que vendieron, y lo que se repite en los que no.

## Los casos

| Caso | Qué hicieron | Resultado | Qué enseña |
|---|---|---|---|
| Kalshi, final de la NBA (jun 2025) | Spot de 30 s hecho por una persona con Veo 3, 2.000 $ y 48 h. Entre 300 y 400 iteraciones de prompt para 15 clips útiles. Concepto absurdo a propósito. | Más de 20 millones de impresiones y prensa. | El concepto se eligió para que las rarezas del modelo parecieran intencionadas. Iterar mucho es parte del coste real. |
| Luo Yonghao × Baidu (jun 2025) | Avatar del presentador en un directo de 6 h con una base de 13.000 fichas de producto. | 7,6 M$ de ventas, 13 M de espectadores, categorías que superaron al humano. | El avatar es lo que se ve; lo que vende es la base de conocimiento de producto. |
| Hatch, dispositivo de sueño (Media.Monks + Gemini) | Creatividades generadas en flujo con brief estructurado y revisión humana. | Coste por compra −31 %, CTR +80 %, coste de producción −97 %. | Lo que escala es el sistema de briefing, no el modelo. |
| H&M, gemelos digitales (2025) | 30 modelos reales fotografiadas y clonadas para responder a tendencias en horas. | Producción de semanas a horas. | La velocidad de respuesta a tendencia es el beneficio, no el ahorro. |
| Coca-Cola, Navidad (2024 y 2025) | Spot nostálgico 100 % IA; la segunda versión "diez veces mejor" según la marca. | Rechazo público en 2024; mejor acogida en 2025. | La nostalgia y la emoción son el terreno donde la IA más se nota. Moda y producto, donde menos. |
| Estudios Ipsos y HBR (2026) | 20 anuncios reales, 3.000 consumidores; y campañas emparejadas humano/IA con el mismo brief. | Solo el 25 % identifica un anuncio IA con seguridad. Los IA rinden peor en venta y en marca aunque no se distingan. | Indistinguible no es eficaz. La diferencia está en el contexto de marca, no en el acabado. |

## Lo que se repite en los que funcionaron

1. **El concepto flattera al modelo.** Absurdo, exagerado, onírico o UGC de móvil: registros donde la imperfección pasa por estilo. Lo que falla: realismo emocional de alto presupuesto donde cada micro-error se nota.
2. **Producto a la vista y en la mano en los primeros tres segundos.** Nada de planos lentos. Se ve qué es y cómo se usa.
3. **Gancho de dolor o de secreto, no de entusiasmo.** Los guiones escritos por IA para actores de IA salen planos y relentlessly positivos. Los que rinden tienen fricción: una queja, una sorpresa, una pega ("no me las quito", "las cambias en 30 días y ya").
4. **Voz nativa en el idioma y el acento del público.** Castellano de España para España. Sincronía labial o no hay confianza.
5. **Ficha de producto exacta dentro del prompt.** Precio, plazo, política de cambio, lo que no se puede decir. Es la parte que viene del cerebro y la que separa el anuncio de tu tienda del anuncio de cualquier tienda.
6. **Muchas iteraciones, pocas horas.** Kalshi: 300 prompts para 15 clips. Se planifica para tirar el 90 %.
7. **Sistema antes que modelo.** Brief estructurado, voz de marca escrita, activos modulares y una revisión humana antes de publicar. Los que ganaron en 2026 no tenían el modelo más nuevo; tenían eso.
8. **Etiqueta de IA visible.** Obligatoria en la UE desde el 2 de agosto de 2026, y bien puesta no penaliza: los estudios dicen que a la gente no le importa saberlo.

## Lo que se repite en los que fallaron

- Emoción nostálgica con acabado casi perfecto (el valle inquietante vende rechazo).
- Guion sin ficha: precios inventados, promesas que la tienda no cumple.
- Producto genérico o cambiado por el modelo (otro color, otro logo).
- Entusiasmo sin fricción. Suena a anuncio y la gente pasa.

## Cómo se convierte esto en prompt

Un anuncio que vende, hoy, tiene esta forma: `[registro que flattera al modelo] + [producto en mano en 3 s] + [gancho con fricción] + [voz nativa con la ficha exacta] + [cierre con condición real: precio, plazo, cambio] + [etiqueta IA]`. La skill `anuncio-ia` del kit lo aplica paso a paso.

Fuentes: [DesignRush, mejores campañas IA](https://www.designrush.com/agency/ad-agencies/trends/best-ai-advertising-campaigns) · [8frame, casos con cifras](https://www.8frame.co/blog/ai-advertising-case-studies-2026) · [Pragmatic, qué funcionó y por qué](https://www.pragmatic.digital/blog/case-study-the-best-ai-advertising-campaigns-and-their-impact) · [inBeat, UGC IA vs real](https://inbeat.agency/blog/ai-ugc-ads-vs-real-ugc) · [Higgsfield, avatares vs creadores](https://higgsfield.ai/blog/ai-avatars-vs-ugc-creators-2026) · [Fast Company, 83 % no distingue](https://www.fastcompany.com/91609674/think-you-can-spot-an-ai-generated-ad-83-of-consumers-got-it-wrong) · [HBR, rinden peor aunque no se distingan](https://hbr.org/2026/09/research-ai-generated-ads-perform-worse-than-human-made-ones-even-when-customers-cant-tell-them-apart) · [TechNode, caso Baidu](https://technode.com/2025/06/17/luo-yonghaos-digital-avatar-draws-over-13-million-viewers-in-ai-powered-baidu-live-commerce-debut/)
