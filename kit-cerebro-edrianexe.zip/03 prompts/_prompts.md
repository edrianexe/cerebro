---
tags: [prompts]
---
# Prompts y agentes del cerebro

- [[montar_el_cerebro]] — el que crea [[01_QUIEN]], [[02_QUE]], [[03_PARA_QUIEN]] y [[04_REGLAS]] desde una descripcion de 6 lineas.
- [[generador_de_prompts_de_campana]] — el metaprompt: no crea el anuncio, escribe el prompt para la herramienta de video que toque.
- [[agente_de_tendencias]] — rellena [[06_TENDENCIAS/_radar|el radar]] cada mes.
- [[ampliar_el_cerebro_con_un_agente]] — como anadir un area nueva (finanzas, RRHH, lo que sea) sin romper lo que hay.
