---
tags: [tareas, metodo]
---
# La cruz de tareas

Dos preguntas por tarea: ¿cuanto cuesta que salga mal? ¿la IA tiene el contexto para hacerla bien?

|  | La IA tiene contexto (esta en el cerebro) | La IA no tiene contexto |
|---|---|---|
| **Error barato** | DELEGAR (radar, borradores, descripciones, resumenes) | DELEGAR con [PREGUNTAR AL DUENO] activado |
| **Error caro** | SUPERVISAR (presupuestos, precios, respuestas a clientes) | SOLO EL DUENO (pedidos, pagos, promesas a clientes) |

Ejemplo: el radar de tendencias es error barato + contexto en [[03_PARA_QUIEN]] y [[04_PRODUCTOS/_catalogo|catalogo]] → delegado. El pedido de reposicion es error caro + la IA no ve el almacen → solo el dueno.

Relacionado: [[_tablero]] · [[04_REGLAS]]
