# Herramientas de septiembre de 2026, con fecha de caducidad

Lo que uso hoy y por qué, y cuándo dejará de ser la mejor opción. Lista corta a propósito: las herramientas caducan, el método no. Fecha: 25 de septiembre de 2026.

| Para qué | Lo que uso | Por qué esta | Caduca cuando |
|---|---|---|---|
| Trabajar con el cerebro (leer la carpeta, seguir llamadas, responder citando notas) | Claude Code, o cualquier asistente que lea archivos de una carpeta | Lee el índice, abre solo lo que toca y escribe notas nuevas. Sin copiar y pegar. | Cuando tu chat de siempre pueda leer y escribir en una carpeta. Algunos ya pueden. |
| Ver el cerebro | Obsidian (gratis) | Archivos de texto normales, grafo de enlaces, no te encierra en ningún formato. | No caduca: son archivos .md. Si Obsidian desaparece, la carpeta sigue. |
| Anuncio en vídeo desde una foto de producto | Seedance 2.5 (vía Freepik o Dreamina) · Kling 3.0 (vía Higgsfield) | Vídeo con voz en castellano y referencia de producto y de persona en una sola generación, 5 a 7 minutos. | Ya. El mejor modelo de vídeo cambia cada dos o tres meses. Lo que no cambia es el prompt que escribe tu metaprompt. |
| Foto de producto sin estudio | Nano Banana 2 (Gemini) | Foto de móvil a bodegón, lifestyle o con modelo. Es el motor por defecto de Google Ads. | Cuando salga la siguiente versión. El prompt vale igual. |
| Avatar que habla con tu cara | HeyGen (avatar) + ElevenLabs clon profesional (voz) | La voz de serie de HeyGen suena a robot; con un clon profesional entrenado con 30-60 minutos de tu audio, no. | Cuando los modelos de vídeo generen tu cara y tu voz con consistencia en una sola pasada. Están cerca. |
| Radar de tendencias mensual | Un agente con búsqueda web (Claude, ChatGPT o Perplexity) con el prompt del kit | Busca, filtra y escribe una nota por tendencia con estado y fuente. | No caduca: es un prompt. Cambia la herramienta debajo cuando quieras. |
| Saber qué recomienda la IA de tu sector (GEO) | Preguntar a ChatGPT, Claude y Gemini "¿qué [tipo de negocio] me recomiendas en [ciudad]?" | Gratis. Si no sales en la respuesta, no existes para el 43 % que ya compra por recomendación de un chatbot. | Nunca. Hazlo cada mes. |
| Anuncios en plataformas | El modo automático de Meta y Google (URL + presupuesto) | Ellos generan creatividades, audiencia y puja. | Es el futuro inmediato. Tu única palanca será el input: la página de producto y el documento de marca. |

## Lo que no uso y por qué

- Skills de marketing genéricas en .md que circulan por internet: no saben nada de tu empresa. Una skill vale cuando lleva tus ejemplos buenos y malos, tu formato de salida y tus líneas rojas.
- Clones de voz instantáneos (3 minutos de audio): sirven para probar, no para publicar.
- Cualquier herramienta que no te deje exportar tus datos en texto plano. Si el cerebro no vive en archivos tuyos, no es tu cerebro.

## La regla

Antes de pagar una herramienta nueva, tres preguntas: ¿lee mi carpeta? ¿escribe en mi carpeta? ¿me deja irme con mis archivos? Si alguna es no, no entra en el sistema.

Ley: cualquier anuncio o vídeo generado con IA que publiques lleva etiqueta desde el 2 de agosto de 2026. Ponlo como regla en tu 04_REGLAS y la IA te lo recordará.
