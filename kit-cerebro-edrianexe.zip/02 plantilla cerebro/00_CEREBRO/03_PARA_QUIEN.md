---
tags: [cerebro, nucleo]
actualizado: AAAA-MM-DD
dueno: nombre
---
# 03_PARA_QUIEN

(Lo genera el prompt 'montar el cerebro' a partir de tu semilla de 6 lineas. Pega aqui el resultado y contesta los [PREGUNTAR AL DUENO].)
