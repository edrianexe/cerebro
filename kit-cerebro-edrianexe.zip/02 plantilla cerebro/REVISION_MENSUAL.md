---
tags: [tareas, metodo]
actualizado: 2026-09-20
dueno: Marta (socia)
---
# Revision mensual del cerebro (15 minutos, primer lunes de mes)

Un cerebro sin dueno se pudre en tres meses. Esta nota es el antidoto. Tres preguntas, con la IA delante:

1. **¿Que ha cambiado?** "Lee 00_INDICE y dime que notas tienen 'actualizado' de hace mas de 60 dias en areas que cambian (precios, stock, campanas, clientes)." Se actualiza la sintesis de cada una o se mueve a historial.
2. **¿Que sobra?** "¿Que notas no se han enlazado ni consultado desde ninguna demo en 90 dias?" Lo que salga, a `_historial`.
3. **¿Que falta?** "¿Que [PREGUNTAR AL DUENO] siguen abiertos en el cerebro?" Se contestan y se borra la marca.

Al terminar: fecha nueva en esta nota y en [[00_INDICE]].

Ultima revision: 2026-09-20 (montaje). Proxima: 2026-10-05.
