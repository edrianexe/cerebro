---
tags: [demo]
---
# D01 — tu primera pregunta

**Pregunta:** 
**Leyo:** (que notas y que archivos abrio)
**Respuesta:** 

Si la respuesta cita tus notas y te pregunta lo que no sabe, el cerebro esta vivo.
