---
tags: [area]
actualizado: AAAA-MM-DD
dueno: nombre
---
# Nombre del area

## Instrucciones
- Que hacer, que no, como calcular, cuando preguntar. Pocas y por orden de importancia.

## Llamadas
- Fuente: `ruta/al/archivo` (hoja o columnas que hay que leer). Una linea por fuente.
- Notas relacionadas: (enlaces)

## Sintesis vigente (fecha)
- Cinco lineas como maximo. Lo que hay que saber hoy.

## Decisiones
- AAAA-MM: que se decidio y por que (enlace a la nota o campana).
