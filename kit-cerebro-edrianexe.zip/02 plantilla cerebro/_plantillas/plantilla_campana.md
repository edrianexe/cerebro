---
tags: [campana]
mes:
canal:
gasto:
ingresos:
roas:
---
# Cxx Nombre

- Producto: (enlace)
- Segmento: (enlace)
- Tendencia que la origino: (enlace)

## Brief
## Resultado
