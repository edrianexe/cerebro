---
tags: [tendencia]
mes:
estado:
---
# Nombre de la tendencia

Detectada: . Estado: . Dato y fuente:
Producto nuestro al que toca: (enlace)
