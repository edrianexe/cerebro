---
tags: [bandeja]
---
# _bandeja (notas sueltas)

Todo lo que no sabes donde va, cae aqui: una foto de un ticket, una idea en el movil, un pantallazo de la competencia, un correo pegado. Sin ordenar, sin titulo bueno, sin pensar.

## Instrucciones para la IA (vaciar la bandeja)
1. Lee cada archivo de esta carpeta.
2. Decide a que area pertenece y muevelo a su carpeta con un nombre que diga lo que hay dentro (fecha + que es).
3. Si cambia la sintesis de un area, actualizala y pon la fecha. Si es una decision, anadela a "Decisiones" de la nota del area.
4. Si es un dato que va en una fuente (un precio, un cliente nuevo), no lo metas en una nota: di en que archivo de _fuentes hay que anadirlo y marca [PREGUNTAR AL DUENO] si falta algo.
5. Lo que no vale para nada, a `_historial`. Nunca se borra.
6. Al terminar, deja la bandeja vacia y escribe en [[00_QUE_TOCA]] que has movido.

El dueno decide; la IA mueve. Ver [[10_DEMOS/D06 vaciar la bandeja|D06]] para un ejemplo hecho.
