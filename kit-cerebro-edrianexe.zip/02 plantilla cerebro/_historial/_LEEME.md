# _historial

Aqui va lo que deja de ser verdad o deja de importar: sintesis antiguas, campanas cerradas hace mas de un ano, notas de la bandeja que no valian. No se borra nunca y no se lee entero nunca: se busca dentro cuando hace falta ("¿que decidimos sobre las Dunk en junio?").

Regla: la IA no abre esta carpeta salvo que se le pida buscar algo concreto en ella.
