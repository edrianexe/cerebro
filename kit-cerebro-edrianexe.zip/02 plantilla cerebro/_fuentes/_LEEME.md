# _fuentes

Aqui viven los DATOS. Las notas del cerebro no los copian: apuntan aqui y dicen que columnas leer.
En una empresa real esto son tus Excel, tu CRM, tu banco, tu Shopify. Aqui son CSV simulados para la demo.

- finanzas/pyg_2026.csv · finanzas/tesoreria_2026-09.csv
- productos/catalogo.csv
- clientes/clientes.csv
- campanas/campanas_2026.csv
