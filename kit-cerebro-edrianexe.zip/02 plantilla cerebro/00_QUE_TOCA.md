---
tags: [indice]
actualizado: AAAA-MM-DD
dueno: nombre
---
# QUE TOCA AHORA (leer antes de hacer nada)

Bloque actual: [mes]. Prioridad unica: [una sola].

1. [tarea]
2. [tarea]
3. [tarea]

Lo que NO toca este mes: [lista corta].

Regla: esta nota se reescribe al cerrar cada sesion de trabajo. Cinco lineas: fase, que se hizo, que espera de quien, siguiente paso. Es lo que hace barata la sesion siguiente.

Ultimo cierre (fecha): 
