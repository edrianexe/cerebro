---
tags: [indice]
actualizado: 2026-09-20
dueno: nombre
---
# CEREBRO de [tu empresa] — Indice

Este vault es el cerebro de la empresa. No es un almacen: son notas cortas con tres cosas, instrucciones precisas, llamadas a donde vive la informacion, y la sintesis vigente. Los datos siguen en sus archivos (_fuentes).

## Instrucciones de lectura (para cualquier IA)
1. Lee este indice y los 4 documentos del nucleo. Nada mas, todavia.
2. Abre SOLO la nota del area que toque la pregunta. Sigue sus llamadas a _fuentes y lee las columnas que indica, no el archivo entero.
3. Responde citando la nota y la fuente de cada dato. Si un dato no esta, escribe [PREGUNTAR AL DUENO] y no lo inventes.
4. Si una nota tiene mas de 90 dias en "actualizado" y el area cambia (precios, stock, campanas), avisa antes de usarla.
5. Si la respuesta vale, guardala como nota nueva en 10_DEMOS enlazando lo que usaste.

## Nucleo (lo que lee siempre)
[[00_QUE_TOCA]] (que toca ahora) · [[01_QUIEN]] · [[02_QUE]] · [[03_PARA_QUIEN]] · [[04_REGLAS]]

## Carpetas de sistema
- `_bandeja`: notas sueltas sin colocar. La IA la vacia ([[_bandeja/_LEEME|instrucciones]]).
- `_fuentes`: los datos (CSV, Excel, exports). Las notas apuntan aqui.
- `_historial`: lo que dejo de ser verdad. No se lee, se busca.
- `_plantillas`: nota de area, campana, tendencia.

## Areas
(Crea solo las que te importen ahora, dos o tres. Una nota por area con la plantilla de _plantillas/plantilla_nota_de_area.md. Ejemplos: 02_CLIENTES, 03_CAMPANAS, 04_PRODUCTOS, 05_FINANZAS, 06_TENDENCIAS, 07_RESULTADOS, 08_TAREAS, 09_PROMPTS, 10_DEMOS.)
